import React, { useState } from 'react';
import ConfirmModal from '../../components/ConfirmModal';
import Toast from '../../components/Toast';
import { formatCurrencyINR } from '../../utils/formatCurrencyINR';
import { BarChart3, Gavel } from 'lucide-react';

const mockAuctions = [
  { id: 'AUCT-001', title: 'Carbon Steel Coils', status: 'Active', bids: 12, currentBid: formatCurrencyINR(45000), end: '2h' },
  { id: 'AUCT-002', title: 'Stainless Steel 316L', status: 'Active', bids: 8, currentBid: formatCurrencyINR(80000), end: '4h' },
  { id: 'AUCT-003', title: 'Structural Steel Beams', status: 'Active', bids: 15, currentBid: formatCurrencyINR(82000), end: '1d' },
];

const Auctions: React.FC = () => {
  const [toast, setToast] = useState<{ open: boolean; message: string; type: 'success' | 'error' }>({ open: false, message: '', type: 'success' });
  const [exportModal, setExportModal] = useState(false);

  const handleExport = () => setExportModal(true);
  const confirmExport = () => {
    setExportModal(false);
    setToast({ open: true, message: 'Data exported successfully.', type: 'success' });
    // Simulate export logic here
  };
  const cancelExport = () => setExportModal(false);

  return (
    <div className="max-w-5xl mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-4">Auction Analytics</h1>
      <div className="flex justify-end mb-4">
        <button onClick={handleExport} className="btn btn-secondary">Export Data</button>
      </div>
      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-50 border border-blue-200 rounded p-4">
          <div className="text-sm text-gray-600 mb-1">Active Auctions</div>
          <div className="text-2xl font-bold text-blue-700">24</div>
          <Gavel className="w-10 h-10 text-blue-500 mt-2" />
        </div>
        <div className="bg-green-50 border border-green-200 rounded p-4">
          <div className="text-sm text-gray-600 mb-1">Total Bids</div>
          <div className="text-2xl font-bold text-green-700">120</div>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded p-4">
          <div className="text-sm text-gray-600 mb-1">Avg. Bid/Item</div>
          <div className="text-2xl font-bold text-yellow-700">8.5</div>
          <BarChart3 className="w-10 h-10 text-yellow-500 mt-2" />
        </div>
      </div>
      {/* Trend Chart (mock) */}
      <div className="bg-white border rounded p-4 mb-8">
        <div className="font-semibold mb-2">Auction Activity Trend (Mock Chart)</div>
        <div className="flex items-end h-32 space-x-2">
          {[12, 19, 3, 5, 2, 3, 7, 8, 9, 10, 12, 15].map((bids, i) => (
            <div key={i} className="flex flex-col items-center flex-1">
              <div className="w-8 bg-blue-400 rounded-t" style={{ height: `${bids * 8}px` }}></div>
              <span className="text-xs mt-1">{['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i]}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Active Auctions Table */}
      <div className="bg-white border rounded p-4">
        <div className="font-semibold mb-2">Active Auctions</div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-gray-600">
              <th className="py-1">ID</th>
              <th className="py-1">Title</th>
              <th className="py-1">Status</th>
              <th className="py-1">Bids</th>
              <th className="py-1">Current Bid</th>
              <th className="py-1">Ends In</th>
            </tr>
          </thead>
          <tbody>
            {mockAuctions.map((a) => (
              <tr key={a.id}>
                <td className="py-1">{a.id}</td>
                <td className="py-1">{a.title}</td>
                <td className="py-1">{a.status}</td>
                <td className="py-1">{a.bids}</td>
                <td className="py-1">{a.currentBid}</td>
                <td className="py-1">{a.end}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ConfirmModal
        open={exportModal}
        title="Export Data"
        description="Export the current auction analytics data as a CSV file?"
        confirmText="Export"
        cancelText="Cancel"
        onConfirm={confirmExport}
        onCancel={cancelExport}
      />
      <Toast
        open={toast.open}
        message={toast.message}
        type={toast.type}
        onClose={() => setToast({ ...toast, open: false })}
      />
    </div>
  );
};

export default Auctions; 